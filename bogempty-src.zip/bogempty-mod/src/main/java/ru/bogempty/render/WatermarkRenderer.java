package ru.bogempty.render;

import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.TitleScreen;
import net.minecraft.client.gui.screen.multiplayer.MultiplayerScreen;

public class WatermarkRenderer {
    public static void init() {
        HudRenderCallback.EVENT.register((ctx, tickCounter) -> {
            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc.currentScreen instanceof TitleScreen || mc.currentScreen instanceof MultiplayerScreen) {
                ctx.getMatrices().push();
                ctx.getMatrices().scale(1.6f, 1.6f, 1f);
                ctx.drawText(mc.textRenderer, "BOGEMPTY", 12, 12, 0xFFCC00FF, true);
                ctx.getMatrices().pop();
            }
        });
    }
}
