package ru.bogempty.render;

import net.minecraft.client.gui.DrawContext;

public class RenderUtil {
    public static void drawRoundedRect(DrawContext ctx, int x, int y, int w, int h, int r, int color) {
        ctx.fill(x + r, y, x + w - r, y + h, color);
        ctx.fill(x, y + r, x + w, y + h - r, color);
    }

    public static void drawBlur(DrawContext ctx, float strength) {
        ctx.fill(0, 0, ctx.getScaledWindowWidth(), ctx.getScaledWindowHeight(), 0x55000000);
    }
}
