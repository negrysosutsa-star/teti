package ru.bogempty.gui;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import ru.bogempty.module.Category;
import ru.bogempty.module.Module;
import ru.bogempty.module.ModuleManager;
import ru.bogempty.module.impl.Theme;
import ru.bogempty.render.RenderUtil;

import java.util.ArrayList;
import java.util.List;

public class Panel {
    public final Category category;
    public int x, y, w = 110, h = 18;
    private final List<Module> mods = new ArrayList<>();

    public Panel(Category cat, int x, int y) {
        this.category = cat;
        this.x = x;
        this.y = y;
        for (Module m : ModuleManager.modules) if (m.category == cat) mods.add(m);
    }

    public void render(DrawContext ctx, int mx, int my, Theme theme) {
        int accent = theme != null ? theme.accent : 0xFFAA00FF;
        int bg = theme != null ? theme.bg : 0xEE1A1A1A;
        RenderUtil.drawRoundedRect(ctx, x, y, w, h + mods.size() * 16, 6, bg);
        ctx.drawText(MinecraftClient.getInstance().textRenderer, category.name(), x + 6, y + 5, accent, false);
        int yy = y + h;
        for (Module m : mods) {
            int col = m.enabled ? accent : 0xFFAAAAAA;
            ctx.drawText(MinecraftClient.getInstance().textRenderer, m.name, x + 8, yy + 4, col, false);
            yy += 16;
        }
    }

    public boolean mouseClicked(double mx, double my, int btn) {
        if (mx < x || mx > x + w) return false;
        int yy = y + h;
        for (Module m : mods) {
            if (my >= yy && my <= yy + 16) {
                m.toggle();
                return true;
            }
            yy += 16;
        }
        return false;
    }
}
