package ru.bogempty.gui;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import ru.bogempty.module.Category;
import ru.bogempty.module.ModuleManager;
import ru.bogempty.module.impl.Blur;
import ru.bogempty.module.impl.Theme;
import ru.bogempty.render.RenderUtil;

import java.util.ArrayList;
import java.util.List;

public class ClickGui extends Screen {
    private final List<Panel> panels = new ArrayList<>();

    public ClickGui() {
        super(Text.literal("BogEmpty"));
        int x = 40;
        for (Category c : Category.values()) {
            panels.add(new Panel(c, x, 40));
            x += 120;
        }
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        Theme theme = (Theme) ModuleManager.get("Theme");
        Blur blur = (Blur) ModuleManager.get("Blur");
        if (blur != null && blur.enabled) {
            RenderUtil.drawBlur(ctx, blur.strength);
        }
        ctx.fill(0, 0, this.width, this.height, 0x66000000);

        for (Panel p : panels) p.render(ctx, mouseX, mouseY, theme);
        super.render(ctx, mouseX, mouseY, delta);
    }

    @Override
    public boolean mouseClicked(double mx, double my, int btn) {
        for (Panel p : panels) if (p.mouseClicked(mx, my, btn)) return true;
        return super.mouseClicked(mx, my, btn);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
