package ru.bogempty;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;
import ru.bogempty.gui.ClickGui;
import ru.bogempty.module.ModuleManager;
import ru.bogempty.render.WatermarkRenderer;

public class BogEmpty implements ClientModInitializer {
    public static final String MOD_ID = "bogempty";
    public static KeyBinding openGui;

    @Override
    public void onInitializeClient() {
        ModuleManager.init();
        openGui = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.bogempty.gui",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_RIGHT_SHIFT,
                "category.bogempty"
        ));
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (openGui.wasPressed()) {
                client.setScreen(new ClickGui());
            }
            ModuleManager.onTick();
        });
        WatermarkRenderer.init();
    }
}
