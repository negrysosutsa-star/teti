package ru.bogempty.module.impl;

import net.minecraft.client.MinecraftClient;
import ru.bogempty.module.Category;
import ru.bogempty.module.Module;

public class FunTimeHelper extends Module {
    public FunTimeHelper() { super("FunTimeHelper", Category.PVE); }

    public void useDesk() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player != null) mc.player.networkHandler.sendChatCommand("kit desk");
    }

    public void useBuff() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player != null) mc.player.networkHandler.sendChatCommand("buff");
    }
}
