package ru.bogempty.module.impl;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerEntity;
import ru.bogempty.module.Category;
import ru.bogempty.module.Module;

public class ESP extends Module {
    public boolean box = true;
    public boolean tracers = false;

    public ESP() { super("ESP", Category.VISUALS); }

    @Override
    public void onRender() {
        // render handled in mixin / hud for simplicity
    }
}
