package ru.bogempty.module;

import ru.bogempty.module.impl.*;

import java.util.ArrayList;
import java.util.List;

public class ModuleManager {
    public static final List<Module> modules = new ArrayList<>();

    public static void init() {
        modules.add(new AimAssist());
        modules.add(new TriggerBot());
        modules.add(new Sprint());
        modules.add(new ESP());
        modules.add(new AspectRatio());
        modules.add(new NoRender());
        modules.add(new GuiMove());
        modules.add(new FunTimeHelper());
        modules.add(new AutoBuff());
        modules.add(new DeskHelper());
        modules.add(new Theme());
        modules.add(new Blur());
    }

    public static void onTick() {
        for (Module m : modules) if (m.enabled) m.onTick();
    }

    public static Module get(String name) {
        return modules.stream().filter(m -> m.name.equalsIgnoreCase(name)).findFirst().orElse(null);
    }
}
