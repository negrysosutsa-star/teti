package ru.bogempty.module.impl;

import ru.bogempty.module.Category;
import ru.bogempty.module.Module;

public class Theme extends Module {
    public int accent = 0xFFAA00FF;
    public int bg = 0xEE1A1A1A;
    public boolean rounded = true;

    public Theme() { super("Theme", Category.SETTINGS); enabled = true; }
}
