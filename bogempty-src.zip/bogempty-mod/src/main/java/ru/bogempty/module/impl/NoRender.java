package ru.bogempty.module.impl;

import ru.bogempty.module.Category;
import ru.bogempty.module.Module;

public class NoRender extends Module {
    public boolean fire = true;
    public boolean bossBar = true;
    public boolean scoreboard = false;
    public boolean pumpkins = true;

    public NoRender() { super("NoRender", Category.VISUALS); }
}
