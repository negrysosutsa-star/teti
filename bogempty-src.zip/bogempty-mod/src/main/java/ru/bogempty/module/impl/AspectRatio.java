package ru.bogempty.module.impl;

import ru.bogempty.module.Category;
import ru.bogempty.module.Module;

public class AspectRatio extends Module {
    public float ratio = 1.6f;

    public AspectRatio() { super("AspectRatio", Category.VISUALS); }
}
