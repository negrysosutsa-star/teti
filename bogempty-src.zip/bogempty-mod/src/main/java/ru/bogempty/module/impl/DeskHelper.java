package ru.bogempty.module.impl;

import ru.bogempty.module.Category;
import ru.bogempty.module.Module;

public class DeskHelper extends Module {
    public DeskHelper() { super("DeskHelper", Category.PVE); }
}
