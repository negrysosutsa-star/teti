package ru.bogempty.module.impl;

import net.minecraft.client.MinecraftClient;
import ru.bogempty.module.Category;
import ru.bogempty.module.Module;

public class Sprint extends Module {
    public Sprint() { super("Sprint", Category.MISC); enabled = true; }

    @Override
    public void onTick() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player != null && mc.player.forwardSpeed > 0 && !mc.player.isSneaking()) {
            mc.player.setSprinting(true);
        }
    }
}
