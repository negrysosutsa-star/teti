package ru.bogempty.module.impl;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.Hand;
import ru.bogempty.module.Category;
import ru.bogempty.module.Module;

public class TriggerBot extends Module {
    public float range = 3.2f;
    public boolean onlyCrit = false;
    private long lastHit;

    public TriggerBot() { super("TriggerBot", Category.COMBAT); }

    @Override
    public void onTick() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null || mc.currentScreen != null) return;
        if (System.currentTimeMillis() - lastHit < 50) return;

        Entity hit = mc.targetedEntity;
        if (hit instanceof LivingEntity le && le.isAlive() && mc.player.distanceTo(le) <= range) {
            if (onlyCrit && mc.player.fallDistance <= 0) return;
            mc.interactionManager.attackEntity(mc.player, le);
            mc.player.swingHand(Hand.MAIN_HAND);
            lastHit = System.currentTimeMillis();
        }
    }
}
