package ru.bogempty.module.impl;

import ru.bogempty.module.Category;
import ru.bogempty.module.Module;

public class AutoBuff extends Module {
    public AutoBuff() { super("AutoBuff", Category.PVE); }
}
