package ru.bogempty.module.impl;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.client.option.KeyBinding;
import ru.bogempty.module.Category;
import ru.bogempty.module.Module;

public class GuiMove extends Module {
    public GuiMove() { super("GuiMove", Category.MISC); }

    @Override
    public void onTick() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (!(mc.currentScreen instanceof HandledScreen)) return;
        KeyBinding[] keys = {
            mc.options.forwardKey, mc.options.backKey,
            mc.options.leftKey, mc.options.rightKey, mc.options.jumpKey
        };
        for (KeyBinding k : keys) {
            KeyBinding.setKeyPressed(k.getDefaultKey(), k.isPressed());
        }
    }
}
