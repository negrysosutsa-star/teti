package ru.bogempty.module.impl;

import ru.bogempty.module.Category;
import ru.bogempty.module.Module;

public class Blur extends Module {
    public float strength = 8f;

    public Blur() { super("Blur", Category.SETTINGS); enabled = true; }
}
