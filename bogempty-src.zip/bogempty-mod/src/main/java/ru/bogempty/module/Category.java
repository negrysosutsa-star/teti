package ru.bogempty.module;

public enum Category {
    COMBAT, VISUALS, PVE, MISC, SETTINGS
}
