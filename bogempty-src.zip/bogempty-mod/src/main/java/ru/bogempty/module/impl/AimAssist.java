package ru.bogempty.module.impl;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import ru.bogempty.module.Category;
import ru.bogempty.module.Module;

public class AimAssist extends Module {
    public float range = 4.5f;
    public float speed = 0.35f;

    public AimAssist() { super("AimAssist", Category.COMBAT); }

    @Override
    public void onTick() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null || mc.currentScreen != null) return;

        LivingEntity target = null;
        double best = range;
        for (PlayerEntity p : mc.world.getPlayers()) {
            if (p == mc.player || !p.isAlive() || p.isInvisible()) continue;
            double d = mc.player.distanceTo(p);
            if (d < best) {
                best = d;
                target = p;
            }
        }
        if (target == null) return;

        Vec3d eyes = mc.player.getEyePos();
        Vec3d aim = target.getPos().add(0, target.getHeight() * 0.85, 0);
        double dx = aim.x - eyes.x, dy = aim.y - eyes.y, dz = aim.z - eyes.z;
        double dist = Math.sqrt(dx * dx + dz * dz);
        float yaw = (float) (MathHelper.atan2(dz, dx) * 180.0 / Math.PI) - 90f;
        float pitch = (float) (-(MathHelper.atan2(dy, dist) * 180.0 / Math.PI));

        float cy = mc.player.getYaw();
        float cp = mc.player.getPitch();
        mc.player.setYaw(cy + MathHelper.wrapDegrees(yaw - cy) * speed);
        mc.player.setPitch(cp + (pitch - cp) * speed);
    }
}
